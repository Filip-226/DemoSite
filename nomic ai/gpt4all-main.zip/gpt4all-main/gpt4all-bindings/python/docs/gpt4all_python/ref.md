# GPT4All Python SDK Reference
::: gpt4all.gpt4all.GPT4All

::: gpt4all.gpt4all.Embed4All