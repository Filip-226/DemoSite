#include <gtest/gtest.h>

TEST(BasicTest, TestInitialization) {
    EXPECT_TRUE(true);
}
