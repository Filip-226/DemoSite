#ifndef MACOSDOCK_H
#define MACOSDOCK_H

struct MacOSDock {
static void showIcon();
static void hideIcon();
};

#endif // MACOSDOCK_H
