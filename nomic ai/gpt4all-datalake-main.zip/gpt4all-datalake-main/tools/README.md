## Downloading the datalake

```bash
aws s3 sync s3://gpt4all-datalake ./datalake_dump
```

