// glsl-read-float.d.ts
declare module 'glsl-read-float' {
  const unpackFloat: (r: number, g: number, b: number, a: number) => number;
  export default unpackFloat;
}
