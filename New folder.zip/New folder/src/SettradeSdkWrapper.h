#pragma once

#include <Windows.h>
#include <string>

#include "SDK/settrade_sdk.h"


class SettradeSdkWrapper {
public:
    SettradeSdkWrapper();
    ~SettradeSdkWrapper();

    bool Initialize();
    void Uninitialize();

    // Wrapper functions for SDK calls
    bool     CreateContext();
    int GetAccountInfo(std::string& accountInfo);
    double GetCurrentPrice(const std::string& symbol);
    // Add more wrapper functions as needed

private:
    HMODULE m_sdkDll;

    tCreateContext     m_tContext;

    // Function pointers for SDK calls
    iCreateContext      m_fCreateContext;
    // Add more function pointers as needed
};