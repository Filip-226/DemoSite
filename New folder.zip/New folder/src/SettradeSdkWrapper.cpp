// SettradeSdkWrapper.cpp
#include "SettradeSdkWrapper.h"

SettradeSdkWrapper::SettradeSdkWrapper() : m_sdkDll(nullptr) {
}

SettradeSdkWrapper::~SettradeSdkWrapper() {
    Uninitialize();
}

bool SettradeSdkWrapper::Initialize() {
    m_sdkDll = LoadLibrary(L"SettradeInterfaceCPPV2.dll");
    if (!m_sdkDll) {
        return false;
    }

    m_fCreateContext = reinterpret_cast<iCreateContext>(GetProcAddress(m_sdkDll, "iCreateContext"));

    return true;
}

void SettradeSdkWrapper::Uninitialize() {
    if (m_sdkDll) {
        FreeLibrary(m_sdkDll);
        m_sdkDll = nullptr;
    }
}

bool SettradeSdkWrapper::CreateContext()
{
    m_fCreateContext(&m_tContext, "UXkvJXoj8rD1iQp9", "A7i1esGoJUqA61pNUJEoXGYYJtC0OktlccL6lxENn1s=", "SANDBOX", "SANDBOX", "SANDBOX1", 10, 20,30,40,50);
    return false;
}

