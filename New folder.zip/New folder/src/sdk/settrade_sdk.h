#pragma once

#include <cstdint>

typedef struct _tRememberMe {
    char*       appId;
    char*       appSecret;
    char*       appCode;
    char*       brokerId;
    uint8_t     enableQueue;
    uint8_t     isRemember;
} tRememberMe;

typedef struct _tConfiguration {
    uint8_t     enableQueue;
    uint64_t    daemonType;
    uint32_t    maxTorelation;
    uint32_t    rateLimit;
} tConfiguration;

typedef struct _tContext {
    uint8_t         isWarning;
    uint8_t         _padding1[7];
    uint64_t        channelId;
    uint64_t        warningMessage;
    tConfiguration  configuration;
} tContext;

typedef struct _tContextResponse {
    uint8_t     success;
    uint32_t    statusCode;
    tContext    data;
    uint64_t    message;
} tContextResponse;

typedef struct _tError {
    uint64_t    message;
} tError;

typedef struct _tCreateContext {
    uint64_t            p0;
    uint64_t            p1;
    uint64_t            p2;
    uint64_t            p3;
    uint64_t            p4;
    uint64_t            p5;
    uint64_t            p6;
    uint8_t             p7;
    uint8_t             p8;
    uint32_t            p9;
    tContextResponse    r0;
    tError              r1;
} tCreateContext;

/*
typedef tCreateContext* (*iCreateContext) (
    uint32_t    arg_48,
    uint8_t     arg_40,
    uint64_t    arg_38,
    uint64_t    arg_30,
    uint64_t    arg_28,
    uint32_t    arg_20
);
*/
typedef tCreateContext* (*iCreateContext) (
    tCreateContext* ctx, const char* a2, const char* a3, const char* a4, const char* a5, const char* a6, __int64 a7, __int64 a8, __int64 a9, __int64 a10, int p9
);

